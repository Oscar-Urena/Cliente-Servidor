import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError
} from "./chunk-KNBGP6OF.js";
import "./chunk-P55DXELB.js";
import "./chunk-FOWG6JAU.js";
import "./chunk-XV7APG3F.js";
import "./chunk-534HTJIS.js";
import "./chunk-MD5ND5KC.js";
import "./chunk-CQQXHZQ5.js";
import "./chunk-HAZYOZPT.js";
import "./chunk-KQYFGZWB.js";
import "./chunk-GERRTHIP.js";
import "./chunk-ZM7DYABX.js";
import "./chunk-ADN67SHQ.js";
import "./chunk-Y3PYHSBQ.js";
import "./chunk-AED2TMGZ.js";
import "./chunk-X7ARPGFS.js";
import "./chunk-O5J3CNTX.js";
import "./chunk-6DU2HRTW.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError
};
